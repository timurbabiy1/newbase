package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
Scanner a=new Scanner(System.in);
long X=a.nextInt();
long Y=a.nextInt();
long N=a.nextInt();
long q=N%(X+Y);
if(q>Y){
    System.out.println(N/(X+Y)*2+2);
}else{
    System.out.println(N/(X+Y)*2+1);
}

    }
}
