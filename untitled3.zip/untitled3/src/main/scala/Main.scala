

import scalikejdbc._

object Main {

  def main(args: Array[String]): Unit = {
    initDb()
    //ConsoleInterface.run()
  }

  def initDb(): Unit ={
    // initialize JDBC driver & connection pool
    Class.forName("org.h2.Driver")
    ConnectionPool.singleton("jdbc:h2:file:./data/testdb:db", "user", "pass")
    //    ConnectionPool.singleton("jdbc:h2:mem:db", "user", "pass")

    initTables()


    //    Hooman.addHooman("Andrey")
    //    Hooman.addHooman("Adolf Alexandrovich")
    //    Doge.addDoge("Sharik")
    //    Doge.addDoge("Woofer")
    //    Doge.addDoge("Awawawaw")
    //    Relations.addRelation(1, 2)
    //    Hooman.reqHoomans().foreach(println)
    //
    //
    //    Relations.getAllHoomanDogePairs().foreach(println)
    //    println(Hooman.hasDoge("Andrey"))
  }


  def initTables():Unit = {
    implicit val session = AutoSession
    sql"""create table if not exists Users(
          id serial not null primary key,
          name  varchar(255) not null,
          registdate DATE,
          aboutuser varchar(255) not null
          )
       """.execute().apply()

    sql"""
         create  table if not exists Themes(
         id serial not null primary key,
name VARCHAR(255) NOT NULL,
about TEXT NOT NULL )
       """.execute().apply()

    sql"""
          create table if not exists Posts(
          id serial not null primary key,
          autor INT ,
data TIMESTAMP NOT NULL,
text TEXT NOT NULL,
about int NOT NULL,
FOREIGN KEY (autor) REFERENCES USERS (id),
FOREIGN KEY (about) REFERENCES THEMES (id)
          )
       """.execute().apply()


  }


}